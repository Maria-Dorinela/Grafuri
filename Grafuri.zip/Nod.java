/**
 * Clasa folosita pentru codificarile fetelor zarului
 * @author Dorinela
 *
 */
public class Nod 
{
	
	public int[] v; //Vector in care retin valorile fetelor zarului dupa prima mutare
	public int[] w; //vector in care retin valorile fetelor zarului dupa a doua mutare
	public int sum; //suma minima din casuta corespunzatoare casutei din matrice
	
	/**
	 * constructor cu 6 parametri
	 * @param x
	 * @param a
	 * @param b
	 * @param c
	 * @param d
	 * @param e
	 */
	public Nod (int x,int a,int b,int c,int d,int e)
	{
		v = new int[6];
		w = null;
		
		v[0]=x;
		v[1]=d;
		v[2]=b;
		v[3]=a;
		v[4]=c;
		v[5]=e;
		
		sum=-1;
	}
	
	/**
	 * initializarea vectorului w
	 */
	public void initializareW()
	{
		w = new int[6];
	}
	
	/**
	 * valorile fetelor daca rotim zarul la dreapta
	 * @return vectorul cu valorile fetelor corespunzatoare
	 */
	public int[] dreapta()
	{
		
		int aux[] = new int[6];
		
		
		aux[0]=v[4];
		aux[1]=v[1];
		aux[2]=v[0];
		aux[3]=v[3];
		aux[4]=v[5];
		aux[5]=v[2];
		
		
		return aux;
	}
	
	
	/**
	 * valorile fetelor daca rotim zarul la stanga
	 * @return vectorul cu valorile fetelor corespunzatoare
	 */
	public int[] stanga()
	{
		
		int aux[] = new int[6];
		
		
		aux[0]=v[2];
		aux[1]=v[1];
		aux[2]=v[5];
		aux[3]=v[3];
		aux[4]=v[0];
		aux[5]=v[4];
		
		
		return aux;
	}
	
	
	/**
	 * valorile fetelor daca rotim zarul in jos
	 * @return vectorul cu valorile fetelor corespunzatoare
	 */
	public int [] spate()
	{
		int aux[] = new int[6];
		
		
		aux[0]=v[1];
		aux[1]=v[5];
		aux[2]=v[2];
		aux[3]=v[0];
		aux[4]=v[4];
		aux[5]=v[3];
		
		
		return aux;
	}
	
	
	/**
	 * valorile fetelor daca rotim zarul in sus
	 * @return vectorul cu valorile fetelor corespunzatoare
	 */
	public int [] fata()
	{
		int aux[] = new int[6];
		
		
		aux[0]=v[3];
		aux[1]=v[0];
		aux[2]=v[2];
		aux[3]=v[5];
		aux[4]=v[4];
		aux[5]=v[1];
		
		
		return aux;
	}
	
	
	/**
	 * valorile fetelor daca rotim zarul de 2 ori la dreapta
	 * @return vectorul cu valorile fetelor corespunzatoare
	 */
	public int[] dreapta1()
	{
		
		int aux[] = new int[6];
		
		
		aux[0]=w[4];
		aux[1]=w[1];
		aux[2]=w[0];
		aux[3]=w[3];
		aux[4]=w[5];
		aux[5]=w[2];
		
		
		return aux;
	}
	
	/**
	 * valorile fetelor daca rotim zarul la stanga de 2 ori
	 * @return vectorul cu valorile fetelor corespunzatoare
	 */
	public int[] stanga1()
	{
		
		int aux[] = new int[6];
		
		
		aux[0]=w[2];
		aux[1]=w[1];
		aux[2]=w[5];
		aux[3]=w[3];
		aux[4]=w[0];
		aux[5]=w[4];
		
		
		return aux;
	}
	
	
	/**
	 * valorile fetelor daca rotim zarul in jos de 2 ori
	 * @return vectorul cu valorile fetelor corespunzatoare
	 */
	public int [] spate1()
	{
		int aux[] = new int[6];
		
		
		aux[0]=w[1];
		aux[1]=w[5];
		aux[2]=w[2];
		aux[3]=w[0];
		aux[4]=w[4];
		aux[5]=w[3];
		
		
		return aux;
	}
	
	/**
	 * valorile fetelor daca rotim zarul in sus de 2 ori
	 * @return vectorul cu valorile fetelor corespunzatoare
	 */
	public int [] fata1()
	{
		int aux[] = new int[6];
		
		
		aux[0]=w[3];
		aux[1]=w[0];
		aux[2]=w[2];
		aux[3]=w[5];
		aux[4]=w[4];
		aux[5]=w[1];
		
		
		return aux;
	}
	
	/**
	 * 
	 * @return vectorul pentru care obtinem suma minima 
	 */
	public int[] minim_dreapta()
	{
		
		if(w!=null)
		{
			int a[] = dreapta();
			int b[] = dreapta1();
			
			
			int sumv,sumw;
			
			sumv = sum + a[0];
			sumw = sum + b[0];
			
			if(sumv>sumw)
				return w;
			else
				return v;
		}
		else
			return v;
	}
	
	/**
	 * 
	 * @return vectorul pentru care obtinem suma minima 
	 */
	public int[] minim_stanga()
	{
		
		if(w!=null)
		{
			
		int a[] = stanga();
		int b[] = stanga1();
		
		
		int sumv,sumw;
		
		sumv = sum + a[0];
		sumw = sum + b[0];
		
		if(sumv>sumw)
			return w;
		else
			return v;
		}
		else
			return v;
	}
	
	/**
	 * 
	 * @return vectorul pentru care obtinem suma minima 
	 */
	public int[] minim_fata()
	{
		
		if(w!=null)
		{
			
		int a[] = fata();
		int b[] = fata1();
		
		
		int sumv,sumw;
		
		sumv = sum + a[0];
		sumw = sum + b[0];
		
		if(sumv>sumw)
			return w;
		else
			return v;
		}
		else
			return v;
	}
	
	/**
	 * 
	 * @return vectorul pentru care obtinem suma minima 
	 */
	public int[] minim_spate()
	{
		
		if(w!=null)
		{
			
		int a[] = spate();
		int b[] = spate1();
		
		
		int sumv,sumw;
		
		sumv = sum + a[0];
		sumw = sum + b[0];
		
		if(sumv>sumw)
			return w;
		else
			return v;
		}
		else
			return v;
	}

}
