Sirbu Maria-Dorinela 
325 CB
Tema 3 PA
Tema este facuta in JAVA

Problema 1 - Fotbal
	Pentru rezolvarea acestei probleme am utilizat hint-ul dat in enuntul temei.
	Pentru fiecare echipa pentru care se doreste a se afla daca poate castiga sau nu am creat o structura de tip graf si vad ce flux maxim pot transporta de la o sursa la o destinatie;
	In cod am scris comentarii la fiecare metoda pe care am creat-o in care am specificaat ce face aceea metoda.

	Clasa Echipe_etape : - cu ajutorul acestei clase retin echipele care au jucat si numarul etapelor pentru fiecare meci;

Clasa Partide : - aceasta clasa o utilizez pentru retinerea meciurilor care au fost jucate (din fisier) impreuna cu rezultatul specific;

Clasa Echipe : - clasa pentru meciuri care are 2 echipe;

Clasa Node : - nodurile din graf : nod1 si nod2;
			-neighbor : vecini fiecarui nod(ArrayList<Node>);
			- muchiile din destinatie pleaca catre noduri care sunt reprezentate ca meciuri(2 echipe);
			-muchiile de la nodurile meciuri pleaca catre nodurile cu echipele corespunzatoare;
			-toate nodurile cu echipe au muchie catre destinatie;

Clasa Muchii : - muchiile intre 2 noduri, costul si fluxul corespunzator muchiei;

Clasa Problema_1 : -citire din fisier;
					- metoda main;
					- creare graf;
					- rezultat pentru echipa: TRUE sau FALSE;
					-metode ajutatoare (comentarii in cod la fiecare metoda)

Costurile de la sursa catre nodurile cu meciuri: 2 * nr meciuri pe care pcele doua echipe le mai au de jucat;
Costurile de la nodurile meci la nodurile echipa : infinit;
Costurile de la nourile echipa la destinatie: punctajul maxim pe care il poare obtine echipa pentru care verific daca poate castiga sau nu - 
											- punctajul curent el echipei din nodul respectiv (=punctajul ibtinut din fisier oentru echipa respectiva);


Dupa crearea grafului pentru fiecare echipa am luat fiecare muchie care pleca din sursa
si am verificat daca costul pe care il am in muchiee il pot transporta la destinatie.
Daca pot transporta toate costurile pentru fiecare muchie din sursa catre destinatie atunci echipa pentru care am creat graful poate castiga.
In caz contrar echipa nu poate castiga.

COMPLEXITATE: 
	In dreptul fiecarui for am specificat complexitatea.
	Pentru metoda evaluare_finala(): O(nr intrebari) * O(1) * O(complexitate creare graf) * O(1) = 
									= O(nr intrebari) * O(creare_graf());
	O(creare_graf) = numarul muchiilor din sursa(numarul meciurilor care mai sunt de jucat inafara de cele in care joaca echipa pentru care doresc sa aflu daca poate castiga) * numarul echipelor care mai au de jucat inafata de echipa interesata;
	
In concluzie complexitatea este : O(nr intrebari) * O(numarul muchiilor din sursa) * O(numarul muchiilor care intra in destinatie).	
	
	
	
	
	

Problema 2 - Zar
	Pentru rezolvarea acestei probleme am folosit programare dinamica.
	Am utilizat o matrice care reprezinta tabla pe care se poate roti zarul pentru a ajunge din sursa in destinatie.
	Calculez suma minima pentru toate elementele matricii care este suma minima dintre cele 2 sume de la pasul anterior + valoarea fetei zarului dupa rotire.
Clasa Nod : - in aceasta Clasa codific zarul;
			- am un vector care reprezinta valorile fetelor dupa o rotire : v;
			-un vector care reprezinta valorile fetelor dupa 2 rotiri : w;
			- 4 metode: dreapta(), stanga(), fata(), spate() care imi returneaza un vector cu valorile fetelor dupa rotirea zarului la dreapta, stanga, sus respectiv jos dupa o rotire;
			- 4 metode: dreapta1(), stanga1(), fata1(), spate1() care imi returneaza un vector cu valorile fetelor dupa rotirea zarului la dreapta, stanga, sus respectiv jos dupa 2 rotiri;
			- 4 metode care imi returneaza vectorul pentru care obtin suma minima pentru cele 4 directii;s
Clasa Problema_2: - contine metoda main;
			- citesc din fisier;
			- completez linia si coloana sursei rotind zarul in cele 4 directii;
			- completez matricea pe bucatii: dreapta-sus, dreapta-jos,stanga-sus,stanga-jos fata de coloana si linia sursei;
COMPLEXITATE:
	In dreptul fiecarui for am scris ce complexitate are (in cod);
	complexitate: O(m-py-1) + O(n-px+1) + O(py) + O(px) + O(n-px+1)*O(m-py+1) + O(n-px+1)*O(py) + O(px)*O(py) + O(px)*O(m-py+1);
	In concluzie complexitatea este de O(n*m) - pentru cazul del mai defavorabil
	
	