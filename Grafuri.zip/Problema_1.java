import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;
import javax.swing.text.html.HTMLDocument.Iterator;

/**
 * rezolvare Problema_1
 * @author Dorinela
 *
 */
public class Problema_1 {
	
	static int N; //numerul de echipe
	static int P; //numarul de partide jucate
	static int K; //numerul de etape ale campionatului
	static int Q; //numarul de intrebari
	static int i;//contor pe care ilo utilizez in unele foruri
	static int j; //contor pe care il utilizez in unele foruri
	
	static ArrayList<String> rezultate = new ArrayList<String>();//in acest ArrayList introduc rezultatele referitoare la echipe: TRUE daca echipa poate castiga si FALSE in caz contrar
	static ArrayList<Partide> meciuri = new ArrayList<Partide>(); //P linii din fisier
	static ArrayList<Integer> intrebare = new ArrayList<Integer>(); //Q linii din fisier
	static ArrayList<Integer> punctaj_echipe = new ArrayList<Integer>(); //punctajul echipelor din meciurile jucate (din fisier)
	static ArrayList<Integer> meciuri_remiza = new ArrayList<Integer>(); //numarul remizelor pentru fiecare echipa (din fisier)
	static ArrayList<Echipe> urmeaza = new ArrayList<Echipe>(); //echipele care mai trebuie sa joace
	static ArrayList<Echipe> jucat = new ArrayList<Echipe>(); //echipele care au jucat
	static ArrayList<Echipe> total_echipe = new ArrayList<Echipe>();
	static ArrayList<Integer> nr_meciuri = new ArrayList<Integer>();//numarul de meciuri pentru fiecare echipa care trebuie sa le mai joace
	static ArrayList<Echipe_etape> stare_echipe = new ArrayList<Echipe_etape>(); //toate echipele inpreuna cu numarul etapelor jucate
	static ArrayList<Echipe_etape> pentru_graf = new ArrayList<Echipe_etape>();//in acest vector bag toate echipele care mai au de jucat etape
	static ArrayList<Integer> echipe = new ArrayList<Integer>();//echipele care mai trebuie sa joace
	static ArrayList<Echipe_etape> cost_sursa_p = new ArrayList<Echipe_etape>();
	static ArrayList<Integer> jocuri_fiecare_echipa = new ArrayList<Integer>();//pentru fiecare echipa pun in acest vector cate jocuri mai are de jucat
	
	
	/**
	 * Metoda care citeste datele din fisierul de intrare
	 */
	public static void citire_din_fisier(){
		
		try      
		{
			File dictFile = new File("fotbal.in"); //fisierul din care citesc date
			Scanner reader = new Scanner(dictFile); //variabila pentru citirea din fisier
			@SuppressWarnings("unused")
			String line,line1,line2;
			line = reader.nextLine();//citesc prima linie din fisier
			String[] linieFisier = line.split(" "); //separ cu ajutorul lui split si introduc datele in variabilele N si M
			
			N = Integer.parseInt(linieFisier[0]);
			P = Integer.parseInt(linieFisier[1]);
			K = Integer.parseInt(linieFisier[2]);
			Q = Integer.parseInt(linieFisier[3]);
			
			while (reader.hasNextLine())//atata timp cat mai am linii in fisier
			{
				
				for(i = 0; i < P; i++){
					line1 = reader.nextLine();
					String[] linieFisier1 = line1.split(" ");
					meciuri.add(new Partide(Integer.parseInt(linieFisier1[0]),Integer.parseInt(linieFisier1[1]),linieFisier1[2]));
					jucat.add(new Echipe(Integer.parseInt(linieFisier1[0]),Integer.parseInt(linieFisier1[1])));
				}
				
				for(i = 0; i < Q; i++){
					line2 = reader.nextLine();
					intrebare.add(Integer.parseInt(line2));
				}
			}
			
	    }
	
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
		}
	
}
	
	/**
	 * @param a
	 * @param b
	 * @return minimul dintre 2 numere 
	 */
	public static int minim(int a, int b){
		if(a <= b)//O(1)
			return a;
		return b;
	}
	
	
	/**
	 * Metoda care initializeaza vectorii utilizati
	 */
	public static void initilizare_vector(){
		for(i = 0; i < N; i++){ //O(N)
			punctaj_echipe.add(i, 0);
			meciuri_remiza.add(i, 0);
			nr_meciuri.add(i,0);
			jocuri_fiecare_echipa.add(i,0);
		}
		int h;
		for(h=0; h < Q; h++){ //O(Q)
			rezultate.add(h,"NU");
		}
		
	}
	
	
	/**
	 * Metoda care initializeaza ArrayList-ul cu perechiile de echipe impreuna cu etapele jucate
	 */
	public static void initializare_stare_echipe(){
		Echipe_etape e = new Echipe_etape(0,0,0);
		for(i = 0; i < total_echipe.size(); i++){ //O(total_echipe.size())
			stare_echipe.add(i,e);
		}
		
	}
	
	
	/**
	 * Metoda care calculeaza pentru fiecare echipa punctajul obtinut in urma partidelor jucate (datele din fisier)
	 */
	public static void calculare_punctaj(){
		for(i = 0; i < P; i++){ //O(P)
			if(meciuri.get(i).rezultat.equals("WIN"))//O(1)
				punctaj_echipe.set(meciuri.get(i).index_echipa_1,punctaj_echipe.get(meciuri.get(i).index_echipa_1)+2);
				
			if(meciuri.get(i).rezultat.equals("DRAW")){ //O(1)
				punctaj_echipe.set(meciuri.get(i).index_echipa_1,punctaj_echipe.get(meciuri.get(i).index_echipa_1)+1);
			    punctaj_echipe.set(meciuri.get(i).index_echipa_2,punctaj_echipe.get(meciuri.get(i).index_echipa_2)+1);
			}	
		}
	}
	

	
	/**
	 * Metoda care introduce in ArrayList-ul "total_echipe" toate combinatiile posibile de echipe care pot juca un meci
	 */
	public static void toate_echipele_posibile(){
		
		for(i = 0; i < N; i++)//O(N)
			for(j = i + 1; j < N; j++) //O(N)
				total_echipe.add(new Echipe(i,j));
		
	}
	

	
	/**
	 * Metoda care verifica care echipe mai au de jucat meciuri si cu cine si seteaza ArrayList-ul "stare_echipe"
	 */
	public static void partide_ramase_nejucate(){
		
		for(i = 0; i < total_echipe.size(); i++){//O( total_echipe.size())
			for(j = 0; j < jucat.size(); j++){//O(jucat.size())
				
				if((total_echipe.get(i).echipa_1 == jucat.get(j).echipa_1 && total_echipe.get(i).echipa_2 == jucat.get(j).echipa_2) || (total_echipe.get(i).echipa_1 == jucat.get(j).echipa_2 && total_echipe.get(i).echipa_2 == jucat.get(j).echipa_1))
					stare_echipe.set(i, new Echipe_etape(total_echipe.get(i).echipa_1,total_echipe.get(i).echipa_2, stare_echipe.get(i).etape_jucate + 1));
				stare_echipe.set(i, new Echipe_etape(total_echipe.get(i).echipa_1,total_echipe.get(i).echipa_2, stare_echipe.get(i).etape_jucate));
				
				
			}
		}
	}
	
	
	/**
	 * Metoda care introduce in ArrayList-ul "pentru_graf" perechiile de echipe necesare pentru construirea grafului
	 */
	public static void echipe_graf(){
		for(i = 0; i < stare_echipe.size(); i++){//O(stare_echipe.size())
			if(stare_echipe.get(i).etape_jucate < K)//O(1)
				pentru_graf.add(new Echipe_etape(stare_echipe.get(i).echipa1, stare_echipe.get(i).echipa2,stare_echipe.get(i).etape_jucate));
		}
	}
	
	
	/**
	 * Metoda care adauga in ArrayList-ul "echipe"  echipele care trebuie sa mai joace (care nu au jucat toate etapele cu toate echipele)
	 */
	public static void echipe_singure(){
		for(i = 0; i < pentru_graf.size(); i++){//O(pentru_graf.size())
			if(!echipe.contains(pentru_graf.get(i).echipa1))
				echipe.add(pentru_graf.get(i).echipa1);
			if(!echipe.contains(pentru_graf.get(i).echipa2))
				echipe.add(pentru_graf.get(i).echipa2);
		}
	}
	
	
	/**
	 * Echipa despre care ma intereseaza sa aflu daca poate castiga sau nu, nu o introduc in graf 
	 * si nici meciurile pe care aceasta le mai are de jucat cu alte echipe
	 * @param echipa_din_intrebare
	 * @return meciurile intre echipele care trebuie sa mai joace fara meciurile in care joaca echipa despre care ma intereseazaa sa aflu daca poate castiga sau nu
	 */
	public static ArrayList<Echipe_etape> echipe_necesare(int echipa_din_intrebare){
		ArrayList<Echipe_etape> pentru_graf_2 = new ArrayList<Echipe_etape>();//in acest vector introduc echipele care imi trebuiesc pentru construirea grafului fara numarul meciurilor pe cale il mai au de jucat
		
		for(i= 0; i < pentru_graf.size(); i++){//O(pentru_graf.size())
			if((pentru_graf.get(i).echipa1 != echipa_din_intrebare) && (pentru_graf.get(i).echipa2 != echipa_din_intrebare))
				pentru_graf_2.add(new Echipe_etape(pentru_graf.get(i).echipa1,pentru_graf.get(i).echipa2,pentru_graf.get(i).etape_jucate));
		}
		
		return pentru_graf_2;
		
	}
	
	
	
	/**
	 * Metoda care calculeaza pentru fiecare echipa numarul meciurilor pe care le mai are de jucat cu toate echipele
	 * Introduc aceste date in ArrayList-ul "nr_meciuri"
	 */
	public static void calc_nr_meciuri(){
		
		for(i = 0; i < N; i ++){//O(N)
			for(j = 0; j < pentru_graf.size(); j++){//O(pentru_graf.size())
				if(i == pentru_graf.get(j).echipa1 || i == pentru_graf.get(j).echipa2)
					nr_meciuri.set(i,nr_meciuri.get(i) + (K-pentru_graf.get(j).etape_jucate)); 
			}
		}
		
	}
	
	
	/**
	 * Pentru echipele care nu mai au de jucat niciun meci cu niciuna din celelalte echipe verific daca punctajul lor curent(cel obtinut cu datele din fisier)
	 * este maxim atunci aceea echipa poate castiga (primul for)
	 * Pentru echipele care au punctajul maxim pe care il pot castiga dupa jucarea tuturor meciurilor < decat punctajul maxim  de mai sus, acele echipe nu pot castiga
	 * punctajul maxim al unei echipe = punctajul curent(obtinut din datele din fisier) + nr meciurilor pe care le mai are de jucat * 2 (2 - pentru ca presupunem ca poate castiga toate meciurile)
	 */
	public static void evaluare(){
		int max = Collections.max(punctaj_echipe);
			for(i = 0; i < intrebare.size(); i++){//O(intrebare.size())
				if(!echipe.contains(intrebare.get(i)) && punctaj_echipe.get(intrebare.get(i)) == max)
					rezultate.set(i, "TRUE");
			}
			int q;
			for( q= 0; q < intrebare.size(); q++){ //O(intrebare.size())
				if(((nr_meciuri.get(intrebare.get(q))*2) + punctaj_echipe.get(intrebare.get(q))) < max)
					rezultate.set(q, "FALSE");	
			}
	}
	
	

	/**
	 *  Calcularea costului de la nodurile cu o singura echipa la destinatie
	 * @param echipa_cercetare - echipa despre care ma interrseaza sa aflu daca poate castiga sau nu
	 * @param echipa_nod - echipa din nod
	 * @return costul muchiei de la nodurile cu o singura echipa la destinatie
	 */
	public static int calc_cost(int echipa_cercetare, int echipa_nod){
		
		int cost = 0;
		int punctaj_maxim_echipa = 0;
		int punctaj_curent = 0;
		int nr_meci = 0;
		int punctaj_echipa_nod = 0;
		
		for(i = 0; i < punctaj_echipe.size(); i++){ //O(punctaj_echipe.size())
			if(echipa_nod == i)
				punctaj_echipa_nod = punctaj_echipe.get(i);	
			if(echipa_cercetare == i)
				punctaj_curent = punctaj_echipe.get(i);
			
		}
		
		for(j = 0; j < nr_meciuri.size(); j++){ //O(nr_meciuri.size();)
			if(echipa_cercetare == j){
				nr_meci = nr_meciuri.get(j);
			}
		}
		punctaj_maxim_echipa = punctaj_curent + (2 * nr_meci);
		cost = punctaj_maxim_echipa - punctaj_echipa_nod;
		return cost;
		
	}

	
	/**
	 * Creare graf pentru fiecare echipa despre care doresc sa aflu daca poate castiga sau nu
	 * Calcularea fluxului maxim
	 * @param intre - echipa care ma intereseaza
	 * @return - 1: daca echipa poate castiga, 0 : daca echipa nu poate castiga
	 */
	public static int creare_graf(int intre){
		
		ArrayList<Muchii> sursa_pereche = new ArrayList<Muchii>();//muchiile intre sursa si perechiile de echipe care mai au de jucat
		ArrayList<Muchii> pereche_echipa = new ArrayList<Muchii>();//muchiile intre perechiile de echipe care mai au de jucat si echipele corespunzatoare
		ArrayList<Muchii> echipa_destinatie = new ArrayList<Muchii>();//muchiile intre echipe si destinatie
		
		ArrayList<Echipe_etape> din_destinatie = new ArrayList<Echipe_etape>();
		din_destinatie = echipe_necesare(intre);
		
		//creez o sursa si o destinatie de tip nod
	    Node sursa = new Node(-100,-100); 
		Node destinatie = new Node(-200,-200);
		
		ArrayList<Node> noduri_singure = new ArrayList<Node>();
		
		int w;
		for(w = 0; w < din_destinatie.size(); w++){ //O( din_destinatie.size())
						
			Node noduri = new Node(din_destinatie.get(w).echipa1, din_destinatie.get(w).echipa2);
			Muchii muchie = new Muchii(sursa,noduri,(K - din_destinatie.get(w).etape_jucate) * 2 ,0);
			sursa.neighbor.add(noduri);
			sursa_pereche.add(muchie);
			
			Node n1 = new Node(din_destinatie.get(w).echipa1);
			Node n2 = new Node(din_destinatie.get(w).echipa2);
			
			if(noduri_singure.contains(n1) == false){
				noduri_singure.add(n1);
				Muchii m = new Muchii(noduri,n1,Integer.MAX_VALUE,0);
				noduri.neighbor.add(n1);
				pereche_echipa.add(m);
				Muchii m1 = new Muchii(n1,destinatie,calc_cost(intre, n1.nod1),0);
				destinatie.neighbor.add(n1);
				n1.neighbor.add(destinatie);
				echipa_destinatie.add(m1);
			}
			else{
				for(int y = 0; y < noduri_singure.size(); y++){ //O(noduri_singure.size())
					if(noduri_singure.get(y).equals(n1)){
						Muchii m = new Muchii(noduri,noduri_singure.get(y),Integer.MAX_VALUE,0);
						noduri.neighbor.add(noduri_singure.get(y));
						pereche_echipa.add(m);
					}
				}
			}
			
			if(noduri_singure.contains(n2) == false){ //O(1)
				noduri_singure.add(n2);
				Muchii m = new Muchii(noduri,n2,Integer.MAX_VALUE,0);
				noduri.neighbor.add(n2);
				pereche_echipa.add(m);
				Muchii m1 = new Muchii(n2,destinatie,calc_cost(intre, n2.nod1),0);
				destinatie.neighbor.add(n2);
				n2.neighbor.add(destinatie);
				echipa_destinatie.add(m1);
			}
			else{
				for(int y1 = 0; y1 < noduri_singure.size(); y1++){ //O(noduri_singure.size())
					if(noduri_singure.get(y1).equals(n2)){
						Muchii m = new Muchii(noduri,noduri_singure.get(y1),Integer.MAX_VALUE,0);
						noduri.neighbor.add(noduri_singure.get(y1));
						pereche_echipa.add(m);
					}
				}
			}	
		}
		
		/**
		 * calcul flux maxim
		 */
		int f;
		int g;
		int raspuns = 0;
		for(f = 0; f < sursa_pereche.size(); f++){
			
			
			if(sursa_pereche.get(f).cost <= (echipa_destinatie.get(0).cost - echipa_destinatie.get(0).flux) + (echipa_destinatie.get(1).cost - echipa_destinatie.get(1).flux)){
				raspuns = 1;
				if(echipa_destinatie.get(0).cost - echipa_destinatie.get(0).flux >= sursa_pereche.get(f).cost - sursa_pereche.get(f).flux){
					echipa_destinatie.get(0).flux += sursa_pereche.get(f).cost - sursa_pereche.get(f).flux;
				    sursa_pereche.get(f).flux += sursa_pereche.get(f).cost;
				   // raspuns = true;
			    }
				else if(echipa_destinatie.get(1).cost - echipa_destinatie.get(1).flux >= sursa_pereche.get(f).cost - sursa_pereche.get(f).flux){
					echipa_destinatie.get(1).flux += sursa_pereche.get(f).cost - sursa_pereche.get(f).flux;
				    sursa_pereche.get(f).flux += sursa_pereche.get(f).cost;
				   // raspuns = true;
			    }
			else{
					
				sursa_pereche.get(f).flux += echipa_destinatie.get(0).cost - echipa_destinatie.get(0).flux;
				echipa_destinatie.get(0).flux = echipa_destinatie.get(0).cost;
				echipa_destinatie.get(1).flux += sursa_pereche.get(f).cost - sursa_pereche.get(f).flux;
				sursa_pereche.get(f).flux = sursa_pereche.get(f).cost;
				//raspuns = true;
			}
				
				
			}
			else
				raspuns = 0;
		}
	
		return raspuns;
	}
	
	
	/**
	 * Creare graf si calculare flux pentru fiecare echipa din ArrayList-ul "intrebare"
	 */
	public static void evaluare_finala(){
		int z;
		for(z = 0; z < intrebare.size(); z++){ //O(intrebare.size())
			int r = 0;
			if(rezultate.get(z).equals("NU")){
			r = creare_graf(intrebare.get(z));
		    if(r == 0)
		    	rezultate.set(z,"FALSE");
		    rezultate.set(z,"TRUE");
			}
		}
		
	}
	
	/**
	 * Metoda main
	 * @param args
	 */
	public static void main(String[] args) {
		
		citire_din_fisier();
	
		initilizare_vector();
		
		calculare_punctaj();
		
		toate_echipele_posibile();
	
		initializare_stare_echipe();
		
		partide_ramase_nejucate();

		echipe_graf();
		
		echipe_singure();
		
		calc_nr_meciuri();
		
		evaluare();
		
		evaluare_finala();
		
		/**
		 * Introducere rezultate pentru fiecare echipa in fisierul de iesire
		 */
		int a;
		try{
			FileWriter scriere = new FileWriter("fotbal.out");
			BufferedWriter iesire = new BufferedWriter(scriere);
			
		   for(a = 0; a < rezultate.size(); a++){
			   iesire.write(rezultate.get(a) + "\n");
		   }
		   iesire.close();
		}catch (Exception e){
			System.err.println("Error: " + e.getMessage());
		}
			
	}

	
}