import java.util.ArrayList;

/**
 * Clasa cu nodurile grafului
 * @author Dorinela
 * Un nod al grafului reprezinta o pereche de 2 echipe care mai au de jucat meciuri intre ele
 */
public class Node {
	
	public int nod1 = 0; //prima echipa care formeaza nodul
	public int nod2 = 0; //a doua echipa care formeaza nodul
	
	
	//ArrayList cu vecinii fiecarui nod
	ArrayList<Node> neighbor = new ArrayList<Node>(); 
	
	/**
	 * constructor implicit
	 */
	public Node(){
		
	}
	
	/**
	 * constructor cu 2 parametri
	 * @param n1
	 * @param n2
	 */
	public Node(int n1, int n2){
		this.nod1 = n1;
		this.nod2 = n2;
	}
	
	/**
	 * constructor cu un parametru
	 * @param n
	 */
	public Node(int n){
		this.nod1 = n;
	}
	
	
	/**
	 * suprascriere metoda toString
	 */
	@Override
    public String toString(){
    	return "(" + nod1 + ","  + nod2 + ")";
    }
	
	
	/**
	 * suprascriere metoda equals
	 */
	@Override
	public boolean equals(Object o){
		Node n = (Node) o;
		if(n.nod1 == this.nod1) 
			return true;
		return false;
	}
}
