import java.io.*;
/**
 * 
 * @author Dorinela
 * Clasa care contine metoda main
 *
 */
public class Problema_2 
{
	static int suma_minima = 0; //suma minima pana la destinatie
	
	public static void main(String args[])
	{
		int m,n;
		m=-1;
		n=-1;
		int a=-1,b=1,c=-1,d=-1,e=-1,f=-1,px=-1,py=-1,sx=-1,sy=-1;
		/**
		 * citire din fisier si paststrarea datelor in variabile
		 */
		try
		{
			FileReader in = new FileReader("zar.in");//fisierul de intrare
			BufferedReader read = new BufferedReader(in);
			String str;
			String str_arr[] = new String[4];
			int counter=0;
			while((str = read.readLine())!=null)
			{
				str_arr[counter]=str;
				counter++;
			}
			
			String[] s = str_arr[0].split(" ");
			n = Integer.parseInt(s[0]); //munarul de linii ale matricii(tablei)
			m = Integer.parseInt(s[1]); //numarul de coloane ale matricii(tablei)
			
			s = str_arr[1].split(" ");
			//valorile fetelor zarului
			a = Integer.parseInt(s[0]);
			b = Integer.parseInt(s[1]);
			c = Integer.parseInt(s[2]);
			d = Integer.parseInt(s[3]);
			e = Integer.parseInt(s[4]);
			f = Integer.parseInt(s[5]);
			
			s = str_arr[2].split(" ");
			//linia si coloana destinatiei
			px = Integer.parseInt(s[0]);
			py = Integer.parseInt(s[1]);
	
			s = str_arr[3].split(" ");
			//linia si coloana sursei
			sx = Integer.parseInt(s[0]);
			sy = Integer.parseInt(s[1]);
			
		}
		catch(Exception err)
		{
			System.err.print(err);
		}
		
		//cream un Nod
		Nod test  = new Nod(a,b,c,d,e,f);
		
		int v[] = test.stanga();
		
		Nod[][] A = new Nod[n][m];//creez o matrice A de Nod
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				A[i][j] = new Nod(a,b,c,d,e,f);
			}
		}
		
		A[px][py].sum=a; //zarul pleaca din destinatie cu fata 1 in sus deci suma din elementul A[px][py] este valoarea fetei 1
		
		/**
		 * Completez linia si coloana matricii pe care se afla sursa
		 */
		
		//completez linia matricii de la sursa la dreapta rotind zarul
		//calculez pentru fiecare element al matricii suma minima necesara ajungerii la acel element prin adunarea valorilor fetelor zarului
		for(int i=py;i<m-1;i++) //O(m-py-1)
		{
		   A[px][i+1].v = A[px][i].dreapta();// O(1)
		   A[px][i+1].sum = A[px][i+1].v[0]+A[px][i].sum;//O(1);
			
		}
		
		//completez coloana matricii de la sursa in jos rotind zarul in jos
		//calculez pentru fiecare element al matricii suma minima necesara ajungerii la acel element prin adunarea valorilor fetelor zarului
		for(int i=px+1;i<n;i++)//O(n-px+1)
		{
			A[i][py].v=A[i-1][py].spate();// O(1)
			A[i][py].sum = A[i-1][py].sum+A[i][py].v[0];// O(1)
		}
		
		//completez linia matricii de la sursa la stanga rotind zarul la stanga
		//calculez pentru fiecare element al matricii suma minima necesara ajungerii la acel element prin adunarea valorilor fetelor zarului
		for(int j=py;j>0;j--)//O(py)
		{
			A[px][j-1].v = A[px][j].stanga();// O(1)
			A[px][j-1].sum = A[px][j-1].v[0]+A[px][j].sum;// O(1)
		}
		
		//completez coloana matricii de la sursa in sus rotind zarul in sus
		//calculez pentru fiecare element al matricii suma minima necesara ajungerii la acel element prin adunarea valorilor fetelor zarului
		for(int i=px;i>0;i--)//O(px)
		{
			A[i-1][py].v=A[i][py].fata();// O(1)
			A[i-1][py].sum = A[i][py].sum+A[i-1][py].v[0];// O(1)
		}
		
		
		//completare sume pentru partea din matrice care se afla in dreapta jos (la dreapta de coloana  sursei si sub linia sursei)
		for(int i=px+1;i<n;i++)//O(n-px+1)
		{
			for(int j=py+1;j<m;j++)//O(m-py+1)
			{
				int sum_up = A[i-1][j].sum + A[i-1][j].spate()[0];//suma daca rotesc zarul in jos
				int sum_left = A[i][j-1].sum + A[i][j-1].dreapta()[0];//suma daca rotesc zarul la dreapta
				//compar cele 2 sume
				if(sum_up>sum_left)
				{
					A[i][j].v = A[i][j-1].dreapta();// O(1)
					A[i][j].sum = A[i][j-1].sum + A[i][j].v[0];// O(1)
				}
				else if(sum_up<sum_left)
				{
					A[i][j].v = A[i-1][j].spate();// O(1)
					A[i][j].sum = A[i-1][j].sum + A[i][j].v[0];// O(1)
				}
				else if(sum_up == sum_left)
				{
					A[i][j].v = A[i][j-1].dreapta();// O(1)
					A[i][j].w = A[i-1][j].spate();// O(1)
					
					A[i][j].sum = A[i][j-1].sum + A[i][j].v[0];// O(1)
					
				}
			}
		}
		
		
		//completare sume pentru partea de matrice care se afla in partea stanga jos ( la stanga  fata de coloana  sursei si sub linia sursei)
			for(int i=px+1;i<n;i++)//O(n-px+1)
			{
				for(int j=py-1;j>=0;j--)//O(py)
				{
					int sum_up = A[i-1][j].sum + A[i-1][j].spate()[0];//suma daca rotesc zarul in jos
					int sum_right = A[i][j+1].sum + A[i][j+1].stanga()[0];//suma daca rotesc zarul la stanga
					//compar cele 2 sume
					if(sum_up>sum_right)
					{
						A[i][j].v = A[i][j+1].stanga();// O(1)
						A[i][j].sum = A[i][j+1].sum + A[i][j].v[0];// O(1)
					}
					else if(sum_up<sum_right)
					{
						A[i][j].v = A[i-1][j].spate();// O(1)
						A[i][j].sum = A[i-1][j].sum + A[i][j].v[0];// O(1)
					}
					else if(sum_up == sum_right)
					{   
						
						A[i][j].v  = A[i][j+1].stanga();// O(1)
						A[i][j].w = A[i-1][j].spate();// O(1)
					    A[i][j].sum  =  A[i][j+1].sum  + A[i][j].v[0];// O(1)
						  	
					}
				}
			}
		
		
		
		//completare sume pentru partea de matrice care de afla la stanga sus fata de sursa (la stanga fata de coloana sursei si deasupra liniei sursei)
			for(int i=px-1;i>=0;i--)//O(px)
			{
				for(int j=py-1;j>=0;j--)//O(py)
				{
					int sum_down = A[i+1][j].sum + A[i+1][j].fata()[0];//suma dacaa rotesc zarul in sus // O(1)
					int sum_right = A[i][j+1].sum + A[i][j+1].stanga()[0];//suma daca rotesc zarul in stanga  // O(1)
					//compar cele 2 sume
					if(sum_down>sum_right)
					{
						A[i][j].v = A[i][j+1].stanga();// O(1)
						A[i][j].sum = A[i][j+1].sum + A[i][j].v[0];// O(1)
					}
					else if(sum_down<sum_right)
					{
						A[i][j].v = A[i+1][j].fata();// O(1)
						A[i][j].sum = A[i+1][j].sum + A[i][j].v[0];// O(1)
					}
					else if(sum_down==sum_right)
					{
						A[i][j].v = A[i][j+1].stanga();// O(1)
						A[i][j].w = A[i+1][j].fata();// O(1)
						
						A[i][j].sum = A[i][j+1].sum + A[i][j].v[0];// O(1)
						
					}
				}
			}
		
		
		//dreapta sus
			//completare sume pentru partea de matrice care se afla la dreapta sus fata de sursa (la dreapta fata de coloana sursei si deasupra liniei sursei)
			for(int i=px-1;i>=0;i--)//O(px)
			{
				for(int j=py+1;j<m;j++)//O(m-py+1)
				{
					int sum_down = A[i+1][j].sum + A[i+1][j].fata()[0];//suma daca rotesc zarul in sus// O(1)
					int sum_left = A[i][j-1].sum + A[i][j-1].dreapta()[0];//suma daca rotesc zarul la dreapta // O(1)
					//compar cele 2 sume
					if(sum_down>sum_left)
					{
						A[i][j].v = A[i][j-1].dreapta();// O(1)
						A[i][j].sum = A[i][j-1].sum + A[i][j].v[0];
					}
					else if(sum_down<sum_left)
					{
						A[i][j].v = A[i+1][j].spate();// O(1)
						A[i][j].sum = A[i+1][j].sum + A[i][j].v[0];// O(1)
					}
					else if(sum_down == sum_left)
					{
						
						A[i][j].v = A[i+1][j].spate();// O(1)
						A[i][j].w = A[i][j-1].dreapta();// O(1)
						A[i][j].sum = A[i+1][j].sum + A[i][j].v[0];// O(1)
							
					}
				}
			}
			
		
		//solutia finala
	 suma_minima = A[sx][sy].sum;// O(1)
		
	 //introducere date in fisierul de iesire
	 BufferedWriter writeToFile=null;
	 try{
	    	writeToFile = new BufferedWriter(new FileWriter("zar.out"));
	    	writeToFile.write(Integer.toString(suma_minima));
	    	writeToFile.close();//inchid fisierul de iesire
		    
	    }catch(IOException ex){
	    	System.out.println(ex);
	    }
	 
	}

}
