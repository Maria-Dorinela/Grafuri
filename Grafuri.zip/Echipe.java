/**
 * 
 * @author Dorinela
 *   clasa pentru meciuri
 */
public class Echipe {
	
	public int echipa_1;//prima echipa
	public int echipa_2;//a doua echipa
	
	/**
	 * constructor implicit
	 */
	public Echipe(){
		
	}
	
	/**
	 * constructor cu 2 parametri
	 * @param e1
	 * @param e2
	 */
	public Echipe(int e1, int e2){
		
		this.echipa_1 = e1;
		this.echipa_2 = e2;
	}

	/**
	 * suprascriere metoda toString
	 */
	@Override
	public String toString(){
		return "(" + echipa_1 + "," + echipa_2  + ")";
	}
}
