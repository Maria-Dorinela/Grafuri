/**
 * 
 * @author Dorinela
 * perechiile de echipe care au jucat impreuna cu rezultatul meciului
 * din fisierul de intrare
 */
public class Partide {
	
	public int index_echipa_1; //prima echipa 
	public int index_echipa_2; //a doua echipa
	public String rezultat; //rezultatul meciului intre cele doua echipe
	
	
	/**
	 * constructor implicit
	 */
	public Partide(){
		
	}
	
	
	/**
	 * constructor cu 3 parametri
	 * @param i1
	 * @param i2
	 * @param r
	 */
	
	public Partide(int i1, int i2, String r){
		this.index_echipa_1 = i1;
		this.index_echipa_2 = i2;
		this.rezultat = r;
	}
	
	
	/**
	 * suprascrierea metodei toString
	 */
	@Override
	public String toString(){
		return "(" + index_echipa_1 + "," + index_echipa_2 + "," + rezultat + ")";
	}

}
