/**
 * muchiile intre nodurile grafului
 * @author Dorinela
 *
 */
public class Muchii {
	
	Node node1; //primul nod al muchiei
	Node node2; //al doilea nod al muchiei
	int cost; //costul muchiei
	int flux; //fluxul muchiei
	
	/**
	 * constructor implicit
	 */
	public Muchii(){
		
	}
	
	/**
	 * constructor cu 4 parametri
	 * @param n1
	 * @param n2
	 * @param c
	 * @param f
	 */
	public Muchii(Node n1, Node n2, int c, int f){
		this.node1 = n1;
		this.node2 = n2;
		this.cost = c;
		this.flux =  f;
	}

	/**
	 * suprascriere metoda toString
	 */
	@Override
	public String toString(){
		return this.node1.toString() + "," + this.node2.toString() + "," + this.cost + "," + this.flux + "; ";
	}
}
