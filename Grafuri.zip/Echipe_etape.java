/**
 * 
 * @author Dorinela
 *  echipele care au jucat si in cate etape
 */
public class Echipe_etape {
	
	public int echipa1;//prima echipe
	public int echipa2;//a doua echipa
	public int etape_jucate; //etapele jucate intre ele, cele din fisier
	
	/**
	 * constructor implicit
	 */
	public Echipe_etape(){
		
	}
	
	/**
	 * constructor cu 3 parametri
	 * @param e1
	 * @param e2
	 * @param etapa
	 */
	public Echipe_etape(int e1, int e2, int etapa){
		
		this.echipa1 = e1;
		this.echipa2 = e2;
		this.etape_jucate = etapa;
	}
	
	/**
	 * suprascriere metoda toString
	 */
	@Override
	public String toString(){
		return "(" + "(" + echipa1 + "," + echipa2 + ")" + "," + etape_jucate + ")"; 
	}

}
